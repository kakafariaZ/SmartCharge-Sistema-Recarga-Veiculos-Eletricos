# SmartCharge 🚗⚡

Sistema inteligente para gerenciamento e reserva de pontos de recarga para veículos elétricos.  

## 📌 Funcionalidades
- Localização e disponibilidade de pontos de recarga em tempo real  
- Reserva antecipada de carregadores  
- Distribuição da demanda para reduzir tempo de espera  
- Liberação automática após recarga  
- Pagamento via PIX ou outros meios eletrônicos 
